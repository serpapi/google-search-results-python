from .lib import google_search_results

def test_query():
    """Tests an API call to get a HTML content"""

    assert isinstance(response, dict)
